# 🚀 Luau Complete PRO for Acode

ปลั๊กอินช่วยเขียนสคริปต์ Luau (Roblox) บน Acode Editor ที่รองรับทั้งสาย Dev และสาย Exploit แบบจัดเต็ม!

## 🌟 ฟีเจอร์หลัก
- **Full Autocomplete**: รองรับคำสั่ง Luau พื้นฐานครบถ้วน
- **Roblox Services**: ช่วยพิมพ์ชื่อ Service ต่างๆ (TweenService, RunService, ฯลฯ)
- **Exploit Functions**: รวมฟังก์ชันยอดฮิต (getgenv, hookmetamethod, setreadonly)
- **Fast & Lightweight**: แยกไฟล์ JSON เพื่อให้โหลดข้อมูลได้รวดเร็วและไม่กินสเปคเครื่อง

## 🛠 วิธีการติดตั้ง
1. ดาวน์โหลดไฟล์ Zip ของปลั๊กอิน
2. เปิดแอพ **Acode**
3. ไปที่ **Settings** > **Plugins**
4. เลือก **Install from file** (ไอคอนรูปไฟล์)
5. เลือกไฟล์ Zip ที่เตรียมไว้ และ Restart แอพ 1 ครั้ง

## 📁 โครงสร้างไฟล์ข้อมูล
- `keywords.json`: คำสั่งจองและโครงสร้างภาษา
- `datatypes.json`: ประเภทข้อมูล (Vector3, CFrame, ฯลฯ)
- `functions.json`: ฟังก์ชันจาก Roblox API และ Exploit API

---
*พัฒนาโดย Alert3z*
