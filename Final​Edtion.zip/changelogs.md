# 📝 Changelogs

## [1.2.0] - ล่าสุด
- **New Structure**: เปลี่ยนมาใช้การโหลดข้อมูลแบบแยกไฟล์ (Flat Structure) เพื่อความเสถียร
- **Data Split**: แยกหมวดหมู่ข้อมูลเป็น `keywords`, `datatypes`, และ `functions`
- **Exploit Update**: เพิ่มฟังก์ชันสำหรับการทำ Script Hub เช่น `hookmetamethod` และ `getgc`

## [1.1.0]
- รวมไฟล์ข้อมูลเข้ากับ `main.js` เพื่อแก้ปัญหาติดตั้งไม่ได้ (Initial Success)

## [1.0.0]
- รุ่นทดสอบแรก (พบปัญหาการหาโฟลเดอร์ src ไม่เจอ)
